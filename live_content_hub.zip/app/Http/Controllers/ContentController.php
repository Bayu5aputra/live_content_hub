<?php

namespace App\Http\Controllers;

use App\Models\Organization;
use App\Models\Content;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ContentController extends Controller
{
    /**
     * Display a listing of contents
     */
    public function index(Organization $organization)
    {
        $contents = $organization->contents()
            ->with('playlists')
            ->ordered()
            ->paginate(15);

        return view('organization.contents.index', compact('organization', 'contents'));
    }

    /**
     * Show the form for creating a new content
     */
    public function create(Organization $organization)
    {
        return view('organization.contents.create', compact('organization'));
    }

    /**
     * Store a newly created content in storage
     */
    public function store(Request $request, Organization $organization)
    {
        $validated = $request->validate([
            'type' => 'required|in:image,video,pdf',
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'file' => 'required|file|max:51200', // 50MB
            'thumbnail' => 'nullable|image|max:2048', // 2MB
            'duration' => 'required|integer|min:1',
            'order' => 'nullable|integer',
            'is_active' => 'boolean',
        ]);

        // Handle file upload
        if ($request->hasFile('file')) {
            $file = $request->file('file');
            $filePath = $file->store('contents/' . $organization->slug, 'public');
            $validated['file_path'] = $filePath;
            $validated['file_url'] = Storage::url($filePath);
        }

        // Handle thumbnail upload
        if ($request->hasFile('thumbnail')) {
            $thumbnail = $request->file('thumbnail');
            $thumbnailPath = $thumbnail->store('thumbnails/' . $organization->slug, 'public');
            $validated['thumbnail_path'] = $thumbnailPath;
            $validated['thumbnail_url'] = Storage::url($thumbnailPath);
        }

        $validated['organization_id'] = $organization->id;
        $validated['order'] = $validated['order'] ?? $organization->contents()->max('order') + 1;
        $validated['is_active'] = $request->has('is_active') ? true : false;

        Content::create($validated);

        return redirect()->route('organization.contents.index', $organization)
            ->with('success', 'Content created successfully!');
    }

    /**
     * Display the specified content
     */
    public function show(Organization $organization, Content $content)
    {
        // Check if content belongs to organization
        if ($content->organization_id !== $organization->id) {
            abort(404);
        }

        $content->load('playlists');

        return view('organization.contents.show', compact('organization', 'content'));
    }

    /**
     * Show the form for editing the specified content
     */
    public function edit(Organization $organization, Content $content)
    {
        // Check if content belongs to organization
        if ($content->organization_id !== $organization->id) {
            abort(404);
        }

        return view('organization.contents.edit', compact('organization', 'content'));
    }

    /**
     * Update the specified content in storage
     */
    public function update(Request $request, Organization $organization, Content $content)
    {
        // Check if content belongs to organization
        if ($content->organization_id !== $organization->id) {
            abort(404);
        }

        $validated = $request->validate([
            'type' => 'sometimes|in:image,video,pdf',
            'title' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'file' => 'sometimes|file|max:51200',
            'thumbnail' => 'sometimes|image|max:2048',
            'duration' => 'sometimes|integer|min:1',
            'order' => 'sometimes|integer',
            'is_active' => 'boolean',
        ]);

        // Handle file upload
        if ($request->hasFile('file')) {
            // Delete old file
            if ($content->file_path) {
                Storage::disk('public')->delete($content->file_path);
            }

            $file = $request->file('file');
            $filePath = $file->store('contents/' . $organization->slug, 'public');
            $validated['file_path'] = $filePath;
            $validated['file_url'] = Storage::url($filePath);
        }

        // Handle thumbnail upload
        if ($request->hasFile('thumbnail')) {
            // Delete old thumbnail
            if ($content->thumbnail_path) {
                Storage::disk('public')->delete($content->thumbnail_path);
            }

            $thumbnail = $request->file('thumbnail');
            $thumbnailPath = $thumbnail->store('thumbnails/' . $organization->slug, 'public');
            $validated['thumbnail_path'] = $thumbnailPath;
            $validated['thumbnail_url'] = Storage::url($thumbnailPath);
        }

        $validated['is_active'] = $request->has('is_active') ? true : false;

        $content->update($validated);

        return redirect()->route('organization.contents.index', $organization)
            ->with('success', 'Content updated successfully!');
    }

    /**
     * Remove the specified content from storage
     */
    public function destroy(Organization $organization, Content $content)
    {
        // Check if content belongs to organization
        if ($content->organization_id !== $organization->id) {
            abort(404);
        }

        // Delete files
        if ($content->file_path) {
            Storage::disk('public')->delete($content->file_path);
        }
        if ($content->thumbnail_path) {
            Storage::disk('public')->delete($content->thumbnail_path);
        }

        $content->delete();

        return redirect()->route('organization.contents.index', $organization)
            ->with('success', 'Content deleted successfully!');
    }

    /**
     * Reorder contents (AJAX)
     */
    public function reorder(Request $request, Organization $organization)
    {
        $validated = $request->validate([
            'contents' => 'required|array',
            'contents.*.id' => 'required|exists:contents,id',
            'contents.*.order' => 'required|integer',
        ]);

        foreach ($validated['contents'] as $item) {
            Content::where('id', $item['id'])
                ->where('organization_id', $organization->id)
                ->update(['order' => $item['order']]);
        }

        return response()->json([
            'success' => true,
            'message' => 'Contents reordered successfully',
        ]);
    }
}
