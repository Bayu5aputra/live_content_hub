<?php

namespace App\Http\Controllers;

use App\Models\Organization;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class OrganizationController extends Controller
{
    /**
     * Display a listing of organizations
     */
    public function index()
    {
        $organizations = Organization::with('users')->paginate(15);
        return view('admin.organizations.index', compact('organizations'));
    }

    /**
     * Show the form for creating a new organization
     */
    public function create()
    {
        return view('admin.organizations.create');
    }

    /**
     * Store a newly created organization in storage
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'nullable|string|max:255|unique:organizations',
            'domain' => 'nullable|string|max:255',
            'admin_email' => 'required|email',
            'admin_name' => 'required|string|max:255',
            'admin_password' => 'required|string|min:8',
        ]);

        $organization = Organization::create([
            'name' => $validated['name'],
            'slug' => $validated['slug'] ?? Str::slug($validated['name']),
            'domain' => $validated['domain'],
            'is_active' => true,
        ]);

        // Create admin user
        $user = User::firstOrCreate(
            ['email' => $validated['admin_email']],
            [
                'name' => $validated['admin_name'],
                'password' => Hash::make($validated['admin_password']),
            ]
        );

        // Attach user to organization as admin
        $organization->users()->syncWithoutDetaching([
            $user->id => ['role' => 'admin']
        ]);

        return redirect()->route('admin.organizations.index')
            ->with('success', 'Organization created successfully!');
    }

    /**
     * Display the specified organization
     */
    public function show(Organization $organization)
    {
        $organization->load(['users', 'contents', 'playlists']);
        return view('admin.organizations.show', compact('organization'));
    }

    /**
     * Show the form for editing the specified organization
     */
    public function edit(Organization $organization)
    {
        return view('admin.organizations.edit', compact('organization'));
    }

    /**
     * Update the specified organization in storage
     */
    public function update(Request $request, Organization $organization)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'slug' => 'required|string|max:255|unique:organizations,slug,' . $organization->id,
            'domain' => 'nullable|string|max:255',
            'is_active' => 'boolean',
        ]);

        $organization->update($validated);

        return redirect()->route('admin.organizations.index')
            ->with('success', 'Organization updated successfully!');
    }

    /**
     * Remove the specified organization from storage
     */
    public function destroy(Organization $organization)
    {
        $organization->delete();

        return redirect()->route('admin.organizations.index')
            ->with('success', 'Organization deleted successfully!');
    }

    /**
     * Add user to organization
     */
    public function addUser(Request $request, Organization $organization)
    {
        $validated = $request->validate([
            'email' => 'required|email',
            'name' => 'required|string|max:255',
            'password' => 'required|string|min:8',
            'role' => 'required|in:admin,editor,viewer',
        ]);

        $user = User::firstOrCreate(
            ['email' => $validated['email']],
            [
                'name' => $validated['name'],
                'password' => Hash::make($validated['password']),
            ]
        );

        $organization->users()->syncWithoutDetaching([
            $user->id => ['role' => $validated['role']]
        ]);

        return back()->with('success', 'User added to organization successfully!');
    }

    /**
     * Remove user from organization
     */
    public function removeUser(Organization $organization, User $user)
    {
        $organization->users()->detach($user->id);

        return back()->with('success', 'User removed from organization successfully!');
    }
}
