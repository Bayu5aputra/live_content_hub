<?php

namespace App\Http\Controllers;

use App\Models\Organization;
use App\Models\Playlist;
use Illuminate\Http\Request;

class DisplayController extends Controller
{
    /**
     * Show the display page (Web View)
     */
    public function show(Organization $organization, Playlist $playlist = null)
    {
        if (!$organization->is_active) {
            abort(404, 'Organization not found or inactive');
        }

        if ($playlist) {
            // Check if playlist belongs to organization
            if ($playlist->organization_id !== $organization->id || !$playlist->is_active) {
                abort(404, 'Playlist not found or inactive');
            }

            $contents = $playlist->contents()
                ->where('contents.is_active', true)
                ->orderByPivot('order')
                ->get();
            $loop = $playlist->loop;
        } else {
            $contents = $organization->contents()
                ->active()
                ->ordered()
                ->get();
            $loop = true;
        }

        return view('display.show', compact('organization', 'playlist', 'contents', 'loop'));
    }

    /**
     * Get content data as JSON (for AJAX)
     */
    public function api(Organization $organization, Playlist $playlist = null)
    {
        if (!$organization->is_active) {
            return response()->json(['error' => 'Organization not found'], 404);
        }

        if ($playlist) {
            // Check if playlist belongs to organization
            if ($playlist->organization_id !== $organization->id) {
                return response()->json(['error' => 'Playlist not found'], 404);
            }

            $contents = $playlist->contents()
                ->where('contents.is_active', true)
                ->orderByPivot('order')
                ->get();
            $loop = $playlist->loop;
        } else {
            $contents = $organization->contents()
                ->active()
                ->ordered()
                ->get();
            $loop = true;
        }

        $data = $contents->map(function ($content) {
            return [
                'id' => $content->id,
                'type' => $content->type,
                'title' => $content->title,
                'file_url' => $content->file_url,
                'thumbnail_url' => $content->thumbnail_url,
                'duration' => $content->duration,
            ];
        });

        return response()->json([
            'organization' => [
                'name' => $organization->name,
                'slug' => $organization->slug,
            ],
            'playlist' => $playlist ? [
                'id' => $playlist->id,
                'name' => $playlist->name,
            ] : null,
            'contents' => $data,
            'loop' => $loop,
            'total' => $data->count(),
        ]);
    }
}
